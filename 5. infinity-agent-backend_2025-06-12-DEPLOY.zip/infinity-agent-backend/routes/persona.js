const express = require('express');
const router = express.Router();
const { getAllPersonas, getPersonaByName } = require('../services/personaService');

router.get('/', (req, res) => {
  res.json({ personas: getAllPersonas() });
});

router.get('/:name', (req, res) => {
  const persona = getPersonaByName(req.params.name);
  if (!persona) return res.status(404).json({ error: 'Persona not found' });
  res.json({ persona });
});

module.exports = router;
