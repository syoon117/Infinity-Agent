const express = require('express');
const router = express.Router();
const { logEvolution, getEvolutions } = require('../services/evolutionService');

router.get('/', (req, res) => {
  res.json({ evolutions: getEvolutions() });
});

router.post('/', (req, res) => {
  logEvolution(req.body);
  res.json({ status: 'Evolution event logged', evolutions: getEvolutions() });
});

module.exports = router;
