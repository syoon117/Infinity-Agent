const express = require('express');
const router = express.Router();
const { getContext, updateContext } = require('../services/contextService');

router.get('/', (req, res) => {
  res.json({ context: getContext() });
});

router.post('/', (req, res) => {
  updateContext(req.body);
  res.json({ context: getContext() });
});

module.exports = router;
