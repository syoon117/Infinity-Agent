const express = require('express');
const router = express.Router();
const { getTokenLog } = require('../services/llmService');
router.get('/', (req, res) => {
  res.json({ tokens: getTokenLog() });
});
module.exports = router;
